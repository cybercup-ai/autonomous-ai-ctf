package everything;

public class LoginBack {
	public String uname;
	public String poke;
	public int num1;
	public int num2;
	public String color;
	public String hash;
	public String level;
	public LoginBack(String uname, String poke, int num2, String color, int num1, String hash) {
		this.uname = uname;
		this.poke = poke;
		this.num2 = num2;
		this.color = color;
		this.hash = hash;
		this.level = "User";
		if(num1 > 0) {
			this.level = "Admin";
		}
	}
}

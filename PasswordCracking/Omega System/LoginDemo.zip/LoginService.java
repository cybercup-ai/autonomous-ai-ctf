package everything;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;
import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;
import java.math.BigInteger;
import java.security.NoSuchAlgorithmException;

//Welcome to our in house login system.
//TODO:
//Implement check in question - began initial steps for the Pokemon question in the data file
//Collect more data from employees for questions such as Middle name, home town, least favorite family member, etc
//Create proper system that is flexable for number of users
//Make a better welcome screen then just saying favorite color is great
//Decode favorite color later


public class LoginService {
	public static void main(String[] arg) {
		//Vars
		String username = "";
		String password = "";
		int index = 255;
		//File input
		FileInputStream inputFile = null;
		try {
			inputFile = new FileInputStream("logins.txt");
		}
		catch(IOException e) {
			e.printStackTrace();
			System.exit(1);
		}
		Scanner file = new Scanner(inputFile);
		//setting up users
		LoginBack[] user = new LoginBack[40];
		for(int i = 0; i < 40; i++) {
			user[i] = new LoginBack(file.next(), file.next(), file.nextInt(), file.next(), file.nextInt(), file.next());
		}
		//User input
		Scanner input = new Scanner(System.in);
		System.out.print("Enter username: ");
		username = input.next();
		System.out.print("Enter password: ");
		password = getMD5Hash(input.next());
		input.close();
		//Checking Login
		for(int i = 0; i < 40; i++) {
			if(user[i].uname.equals(username) && user[i].hash.equals(password)) {
				index = i;
			}
		}
		//Output
		if(index != 255) {
			System.out.print("Hello " + user[index].level + user[index].num2 + "@Omegas\n");
			System.out.print(user[index].color + " is always great");
		}
		else {
			System.out.print("Wrong Login");
		}
		
	}
	//hash check
	   public static String getMD5Hash(String input) {
	       try {
	           MessageDigest md = MessageDigest.getInstance("MD5");
	           byte[] messageDigest = md.digest(input.getBytes(StandardCharsets.UTF_8));
	           BigInteger no = new BigInteger(1, messageDigest);
	           StringBuilder hexString = new StringBuilder(no.toString(16));

	           while (hexString.length() < 32) {
	               hexString.insert(0, '0');
	           }

	           return hexString.toString();
	       } catch (NoSuchAlgorithmException e) {
	           throw new RuntimeException(e);
	       }
	   }
}
